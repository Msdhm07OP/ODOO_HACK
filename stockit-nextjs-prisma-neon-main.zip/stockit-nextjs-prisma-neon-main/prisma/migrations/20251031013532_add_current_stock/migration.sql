-- AlterTable
ALTER TABLE "Product" ADD COLUMN     "currentStock" DECIMAL(12,3) NOT NULL DEFAULT 0;
