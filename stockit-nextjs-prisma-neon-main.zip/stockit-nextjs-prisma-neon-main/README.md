# StocKit

<!-- PROJECT LOGO -->
<p align="center">
  <a href="#">
    <img src="public/icon.png" alt="StocKit Logo" width="120" height="120">
  </a>
</p>

ระบบจัดการสินค้าคงคลังแบบครบครันที่สร้างด้วย Next.js 16 พร้อม Stack Auth สำหรับการรักษาความปลอดภัย เหมาะสำหรับธุรกิจขนาดเล็กถึงกลางที่ต้องการติดตามสต็อกสินค้า, ตรวจสอบสินค้าใกล้หมด, และจัดการข้อมูลสินค้าจากหน้าจอเดียว

## Features
- **ระบบรักษาความปลอดภัย** ด้วย Stack authentication พร้อม protected routes และ user-scoped Prisma queries
- **จัดการสินค้าคงคลัง** ด้วย server actions สำหรับ CRUD operations, การ validate ด้วย `react-hook-form` + `zod`, toast feedback, dialog และ empty/loading states
- **เอนจิน Moving Average Cost** ที่จัดการ `Product.currentStock` และ `Product.avgCost` อัตโนมัติ เมื่อสินค้าออก (OUT) จะใช้ราคาเฉลี่ย ส่วนสินค้าเข้า (IN) จะคำนวณต้นทุนเฉลี่ยแบบถ่วงน้ำหนักใหม่
- **Dashboard ข้อมูลเชิงลึก** แสดง KPI tiles, สถานะสต็อกแบบเรียลไทม์, คำแนะนำการเติมสต็อก, คะแนนประสิทธิภาพ, แผนภูมิสินค้าใหม่รายสัปดาห์, และกิจกรรมล่าสุด
- **Layout ปรับตัวได้** ด้วย sidebar แบบพับได้, breadcrumb header, skeleton placeholders, และ UI components แบบนำกลับมาใช้ได้
- **ฐานข้อมูล Prisma-PostgreSQL** แยกข้อมูลตาม user พร้อม `revalidatePath` เพื่อความสดใหม่ของ UI หลังการแก้ไขข้อมูล

## Dashboard Insights
- **กลุ่มเมตริกหลัก 3 ตัว** ครอบคลุมจำนวนสินค้าทั้งหมด, จำนวนสินค้าใกล้หมด, และมูลค่าสินค้าคงคลังรวม พร้อมตัวชี้วัดแนวโน้มรายสัปดาห์
- **รายการสถานภาพสต็อก** แสดงสถานะแบบ traffic-light, เกจปริมาณแบบเรียลไทม์, และปุ่มเติมสต็อกด่วนสำหรับสินค้าเสี่ยง
- **คำแนะนำการเติมสต็อก** ไฮไลต์จุดสั่งซื้อใหม่และแนะนำปริมาณที่ควรซื้อ
- **แผนภูมิประสิทธิภาพแบบ radial** สรุปเปอร์เซ็นต์ของสินค้าในสต็อก, สินค้าใกล้หมด, และสินค้าหมดสต็อก พร้อมคะแนนประสิทธิภาพโดยรวม
- **แผนภูมิสินค้ารายสัปดาห์** แสดงจำนวนสินค้าใหม่ที่เพิ่มเข้ามาใน 12 สัปดาห์ที่ผ่านมา
- **ฟีดกิจกรรมล่าสุด** รายละเอียดการเคลื่อนไหวสต็อกล่าสุด พร้อมประเภท, เหตุผล, ปริมาณ, และเวลาแบบสัมพันธ์

## Tech Stack
- Next.js 16 (App Router, Server Components, Route Handlers)
- React 19 + TypeScript
- Tailwind CSS 4 + tw-animate
- Prisma ORM + PostgreSQL (`DATABASE_URL`)
- Stack SDK (`@stackframe/stack`) สำหรับการจัดการ auth/session
- Recharts, react-hook-form, zod, sonner, class-variance-authority, tailwind-merge, Lucide icons

## Directory Structure
```
app/                      // หน้าหลัก, dashboard, inventory, settings, Stack handler
├── (protected)/          // เส้นทางที่ต้องล็อกอิน
│   ├── categories/       // จัดการหมวดหมู่สินค้า
│   ├── dashboard/        // หน้า dashboard หลัก
│   ├── inventory-activities/  // ประวัติการเคลื่อนไหวสต็อก
│   ├── products/         // จัดการสินค้า
│   └── units/           // จัดการหน่วยสินค้า
└── handler/             // Stack Auth handlers
components/              // UI ส่วนกลาง (sidebar, header, ตาราง, แผนภูมิ)
├── charts/              // แผนภูมิและกราฟต่างๆ
├── data-table/          // ตารางข้อมูลแบบ reusable
├── skeleton/            // Loading skeletons
└── ui/                  // UI components พื้นฐาน
lib/
├── actions/             // Server actions ที่ wrap service operations
├── auth/                // การจัดการ authentication
├── db/                  // การเชื่อมต่อฐานข้อมูล
├── errors/              // Error handling และ custom errors
├── security/            // Security utilities
├── services/            // Domain services ที่ใช้ Prisma
├── types/               // DTOs และ type definitions
└── utils/               // Utility functions และ helpers
stack/                   // การกำหนดค่า Stack client/server
prisma/                  // Schema, migrations, reset script
public/                  // Static assets
```

## Stock Movements Management System
- **Logic หลัก** อยู่ใน `lib/services/stock-movements.ts` ซึ่งการ create/update/delete แต่ละครั้งทำงานภายใน Prisma transaction และมอบหมายการคำนวณราคาและสต็อกให้ MAC helpers
- **การบังคับใช้ ownership** ด้วย `assertProductOwnership` ช่วยให้ user แก้ไขได้เฉพาะสินค้าของตัวเองเท่านั้น แม้ในการทำงานแบบ nested transactions
- **คณิตศาสตร์ Moving Average Cost แบบบริสุทธิ์** อยู่ใน `lib/utils/stock-movement-math.ts` พร้อมการทดสอบด้วย Vitest ทำให้พัฒนากฎการคำนวณต้นทุนได้ง่าย โดยไม่ต้องแก้ไขโค้ด Prisma

## Efficiency Score Calculation
- เราคำนวณ `efficiencyScore` ใน [`lib/utils/dashboard.ts`](lib/utils/dashboard.ts) โดยเริ่มจากการแจกแจงสินค้า:
  - `inStockPercentage = round((inStockCount / totalProducts) × 100)`
  - `lowStockPercentage = round((lowStockCount / totalProducts) × 100)`
  - `outOfStockPercentage = round((outOfStockCount / totalProducts) × 100)`
- คะแนนสุดท้ายผสมผสานค่าเหล่านี้ด้วยการลงโทษแบบถ่วงน้ำหนักและจำกัดค่าระหว่าง 0–100:

  ```
  efficiencyScore = round(
    clamp(
      (inStockPercentage × 0.7) +
      ((100 − lowStockPercentage) × 0.2) +
      ((100 − outOfStockPercentage) × 0.1),
      0,
      100
    )
  )
  ```

- หากไม่มีสินค้าเลย (`totalProducts = 0`) คะแนนจะแสดงเป็น `null`

## Database Schema
Prisma models ถูกจำกัดขอบเขตด้วย `userId` ดังนั้นแต่ละ workspace ที่ authenticated ด้วย Stack จะมีข้อมูลสินค้าเป็นของตัวเอง คอลัมน์ที่มีเครื่องหมาย `*` คือ required

### Product (สินค้า)
| คอลัมน์*        | ประเภท                | หมายเหตุ                                                      |
|----------------|----------------------|-------------------------------------------------------------|
| id*            | `String`             | Primary key ที่สร้างด้วย `cuid()`                             |
| userId*        | `String`             | Foreign key ไปยัง Stack user เพื่อแยกข้อมูลตาม user          |
| name*          | `String`             | ชื่อสินค้าที่แสดง                                              |
| sku            | `String?`            | รหัสสินค้า (ไม่ซ้ำในแต่ละ user)                               |
| lowStockAt     | `Int?`               | จุดเตือนสต็อกน้อย (ไม่บังคับ)                                 |
| categoryId     | `String?`            | FK ไปยัง `Category` (ไม่บังคับ) (`@db.VarChar(255)`)          |
| unitId*        | `String`             | FK ไปยัง `Unit` (บังคับ) (`@db.VarChar(255)`)                 |
| currentStock*  | `Decimal(12,3)`      | จำนวนสต็อกปัจจุบันที่ cache ไว้ (ค่าเริ่มต้น `0`)              |
| avgCost*       | `Decimal(12,2)`      | ต้นทุนเฉลี่ยแบบ moving-average ที่ cache ไว้ (ค่าเริ่มต้น `0`) |
| createdAt*     | `DateTime`           | วันที่สร้าง (ค่าเริ่มต้น `now()`)                              |
| updatedAt*     | `DateTime`           | วันที่แก้ไขล่าสุด (อัปเดตอัตโนมัติ)                           |

**Indexes**
- `@@unique([userId, sku])` - SKU ไม่ซ้ำในแต่ละ user
- `@@index([userId, name])` - ค้นหาสินค้าตามชื่อ
- `@@index([createdAt])` - เรียงตามวันที่สร้าง

**ความสัมพันธ์**
- `category` (ไม่บังคับ) ผ่าน `categoryId`
- `unit` (บังคับ) ผ่าน `unitId`
- `movements` แบบ one-to-many

### Category (หมวดหมู่)
| คอลัมน์*    | ประเภท       | หมายเหตุ                                                 |
|------------|-------------|--------------------------------------------------------|
| id*        | `String`    | Primary key ที่สร้างด้วย `cuid()`                        |
| userId*    | `String`    | เจ้าของ Stack user                                      |
| name*      | `String`    | ชื่อหมวดหมู่ที่ไม่ซ้ำในแต่ละ user                        |
| createdAt* | `DateTime`  | วันที่สร้าง (ค่าเริ่มต้น `now()`)                        |
| updatedAt* | `DateTime`  | วันที่แก้ไขล่าสุด (อัปเดตอัตโนมัติ)                     |

**Indexes**
- `@@unique([userId, name])` - ชื่อหมวดหมู่ไม่ซ้ำในแต่ละ user
- `@@index([userId])` - ค้นหาตาม user

**ความสัมพันธ์**
- `products` แบบ one-to-many

### Unit (หน่วย)
| คอลัมน์*    | ประเภท       | หมายเหตุ                                                 |
|------------|-------------|--------------------------------------------------------|
| id*        | `String`    | Primary key ที่สร้างด้วย `cuid()`                        |
| userId*    | `String`    | เจ้าของ Stack user                                      |
| name*      | `String`    | ป้ายกำกับที่แสดง เช่น "ชิ้น", "กล่อง", "กิโลกรัม"        |
| createdAt* | `DateTime`  | วันที่สร้าง (ค่าเริ่มต้น `now()`)                        |
| updatedAt* | `DateTime`  | วันที่แก้ไขล่าสุด (อัปเดตอัตโนมัติ)                     |

**Indexes**
- `@@unique([userId, name])` - ชื่อหน่วยไม่ซ้ำในแต่ละ user
- `@@index([userId])` - ค้นหาตาม user

**ความสัมพันธ์**
- `products` แบบ one-to-many

### StockMovement (การเคลื่อนไหวสต็อก)
| คอลัมน์*       | ประเภท                | หมายเหตุ                                                               |
|---------------|----------------------|-----------------------------------------------------------------------|
| id*           | `String`             | Primary key ที่สร้างด้วย `cuid()`                                      |
| productId*    | `String`             | FK ไปยัง `Product`                                                    |
| userId*       | `String`             | เจ้าของ Stack user                                                    |
| movementType* | `MovementType`       | Enum บอกประเภทการเคลื่อนไหว IN หรือ OUT                               |
| quantity*     | `Decimal(12,3)`      | จำนวนที่เคลื่อนไหว                                                     |
| unitCost      | `Decimal(12,2)?`     | ราคาต่อหน่วยที่บันทึกไว้เพื่อประวัติ; IN ต้องใส่, OUT ใช้ราคาเฉลี่ยสินค้า |
| totalCost     | `Decimal(14,2)?`     | คำนวณจาก `quantity × unitCost`                                         |
| referenceType | `ReferenceType`      | ค่าเริ่มต้น `MANUAL`                                                   |
| referenceId   | `String?`            | รหัสเอกสารอ้างอิง (ไม่บังคับ)                                          |
| reason        | `String?`            | เหตุผลการปรับยอด (ไม่บังคับ)                                          |
| createdAt*    | `DateTime`           | วันที่สร้าง (ค่าเริ่มต้น `now()`)                                      |
| updatedAt*    | `DateTime`           | วันที่แก้ไขล่าสุด (อัปเดตอัตโนมัติ)                                   |

**Indexes**
- `@@index([productId])` - ค้นหาประวัติการเคลื่อนไหวของสินค้า
- `@@index([createdAt])` - ค้นหาตามวันที่
- `@@index([movementType, createdAt])` - กรองรายงานตามประเภทและวันที่
- `@@index([referenceType, referenceId])` - กรองตามเอกสารอ้างอิง
- `@@index([userId, createdAt])` - กรองตาม user และวันที่
- `@@index([productId, movementType])` - กรองสินค้าตามประเภทการเคลื่อนไหว
- `@@index([productId, createdAt])` - กรองสินค้าตามวันที่

**ความสัมพันธ์**
- เป็นของ `product`

### Enums
- `MovementType`: `IN` (สินค้าเข้า), `OUT` (สินค้าออก)
- `ReferenceType`: `PURCHASE` (ซื้อ), `SALE` (ขาย), `RETURN` (คืน), `TRANSFER` (โอน), `ADJUSTMENT` (ปรับยอด), `MANUAL` (บันทึกเอง)

## Prerequisites
- Node.js 20+
- pnpm
- PostgreSQL database
- Stack account with project keys (https://stackauth.com)
## Environment Variables
สร้างไฟล์ `.env.local` (หรือ `.env`) พร้อมค่าต่อไปนี้โดยใช้ข้อมูลของคุณเอง:

```
DATABASE_URL="postgresql://USER:PASSWORD@HOST:PORT/DB_NAME"
NEXT_PUBLIC_STACK_PROJECT_ID="<your-stack-project-id>"
NEXT_PUBLIC_STACK_PUBLISHABLE_CLIENT_KEY="<your-stack-publishable-client-key>"
STACK_SECRET_SERVER_KEY="<your-stack-server-key>"
```

สคริปต์ `prisma/seed.ts` (ไม่บังคับ) อ้างอิงถึง demo user ID—ปรับแต่งหากคุณต้องการใส่ข้อมูลตัวอย่าง

## Getting Started
1. ติดตั้ง dependencies
   ```bash
   pnpm install
   ```
2. ใช้ database migrations และสร้าง Prisma Client
   ```bash
   pnpm dlx prisma migrate dev
   ```
3. เริ่มต้น development server
   ```bash
   pnpm dev
   ```
4. เปิด http://localhost:3000 และเข้าสู่ระบบด้วย Stack เพื่อเข้าใช้หน้า dashboard และ inventory

## Contributing

ผมยังต้องฝึกอีกเยอะและโปรเจคนี้ก็ยังมีช่องว่างให้พัฒนาอีกมากครับ
หากคุณพบเห็นส่วนไหนที่สามารถปรับปรุงให้ดีขึ้นได้ — ไม่ว่าจะเล็กหรือใหญ่ — ยินดีรับทุกความช่วยเหลือจากทุก ๆ ท่านเลยครับ 🙏

ขั้นตอนร่วมสนับสนุน:
1. Fork repository
2. สร้าง branch ใหม่สำหรับการปรับปรุงของคุณ
3. ส่ง Pull Request พร้อมเล่าว่าคุณปรับปรุงอะไร อย่างไรบ้าง และทำไมถึงสำคัญ

ทุกการมีส่วนร่วม ทั้งโค้ด ไอเดีย หรือ feedback ช่วยให้โปรเจคนี้เติบโตเร็วขึ้นมากครับ
ขอบคุณที่มาช่วยกันสร้างสิ่งนี้ให้ดีขึ้นไปด้วยกันครับ 🩵

---

**🧑‍💻 Happy Hacking!**
